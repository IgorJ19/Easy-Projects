package com.mycompany.milionerzy;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.JFrame;


public class KolejnePytanie extends Milionerzy implements WindowFocusListener{
 
    public KolejnePytanie(JFrame parent){
        
        String [] wygrane = {"" ,"1000zł", "2000zł", "5000zł", "10 000zł", "20 000zł", "40 000zł", "75 000zł", "125 000zł", "250 000zł", "500 000zł", "1 000 000zł"};
       this.setTitle("pytanie za:" + wygrane[iloscPoprawnych]);
       this.setBounds(parent.getBounds());
       
       
     initComponents2();
    }
    
    public void initComponents2() 
    {
        
             if(iloscWykorzystanychPolnaPol >= 1){
                 polNaPol.setBackground(Color.red);
                 polNaPol.setEnabled(false);
                }
             
              if(iloscWykorzystanychPublicznosci >= 1){
                 pomocPublicznosci.setBackground(Color.red);
                 pomocPublicznosci.setEnabled(false);
                 }
             
             if(iloscWykorzystanychTelefonow >= 1){
                 telDoPrzyjaciela.setBackground(Color.red);
                 telDoPrzyjaciela.setEnabled(false);
                 }
         
   
     
        
    }
    
      @Override
    public void windowGainedFocus(WindowEvent e) {
        panelPrzyciskowDol.setVisible(true);
    panelPrzyciskowGora.setVisible(true);
    panelPytania.setVisible(true); 
    
    }

    @Override
    public void windowLostFocus(WindowEvent e) {
    panelPrzyciskowDol.setVisible(false);
    panelPrzyciskowGora.setVisible(false);
    panelPytania.setVisible(false);
        System.out.println("stracilo focus");}
    
   
        public static void main(String[] args) {
        new Milionerzy().setVisible(true);
    }
    
}
