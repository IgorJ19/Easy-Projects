package com.mycompany.milionerzy;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.event.AWTEventListener.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormatSymbols;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
public class Milionerzy extends JFrame implements WindowListener{
    
    public Milionerzy(){
        this.setTitle("Wygraj Milion! :), pytanie za 500zł");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
       
        initComponents();
    }
    public void initComponents(){
            
        
        losujPytanie();
        zaznaczonyPoziomWygranej();
       
       
        
       
        this.setBounds((szer-szerRamki)/8, (wys-wysRamki)/8, szerDziel*3, wysDziel*3);
        this.setResizable(false);
        this.addWindowListener(this);
        pasekPomocy.add(polNaPol);
        pasekPomocy.add(telDoPrzyjaciela);
        pasekPomocy.add(pomocPublicznosci);
        polNaPol.setFont(new Font("monospyced", szer, 13));
        telDoPrzyjaciela.setFont(new Font("monospyced", szer, 12));
        pomocPublicznosci.setFont(new Font("monospyced", szer, 12));
        this.getContentPane().add(pytanie);
        PoziomWygranej.setFont(new Font("bold", szer, 15));
        PoziomWygranej1.setFont(new Font("bold", szer, 15));
        PoziomWygranej2.setFont(new Font("bold", szer, 15));
        PoziomWygranej3.setFont(new Font("bold", szer, 15));
        PoziomWygranej4.setFont(new Font("bold", szer, 15));
        PoziomWygranej5.setFont(new Font("bold", szer, 15));
        PoziomWygranej6.setFont(new Font("bold", szer, 15));
        PoziomWygranej7.setFont(new Font("bold", szer, 15));
        PoziomWygranej8.setFont(new Font("bold", szer, 15));
        PoziomWygranej9.setFont(new Font("bold", szer, 15));
        PoziomWygranej10.setFont(new Font("bold", szer, 15));
        PoziomWygranej11.setFont(new Font("bold", szer, 15));
    GroupLayout layout = new GroupLayout (getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setHorizontalGroup //poziom
        (
           layout.createSequentialGroup()
                   .addContainerGap(this.getSize().width,Integer.MAX_VALUE)
                 
                       .addGroup
                (
                        layout.createParallelGroup().addComponent(pytanie, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(panelPrzyciskowGora, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(panelPrzyciskowDol)
                )
                    .addGap(szer/12)
                   .addGroup(
                    layout.createParallelGroup().addComponent(pasekPomocy).addComponent(PoziomWygranej11).addComponent(PoziomWygranej10).addComponent(PoziomWygranej9).addComponent(PoziomWygranej8).addComponent(PoziomWygranej7).addComponent(PoziomWygranej6).addComponent(PoziomWygranej5).addComponent(PoziomWygranej4).addComponent(PoziomWygranej3).addComponent(PoziomWygranej2).addComponent(PoziomWygranej1).addComponent(PoziomWygranej).addComponent(ZatrzymajGre)
                   )
               
              
        );
       layout.setVerticalGroup //pion
        (
                layout.createSequentialGroup()        
                        .addContainerGap(this.getSize().height,Integer.MAX_VALUE)
                                .addComponent(pasekPomocy)
                        .addComponent(PoziomWygranej11).addComponent(PoziomWygranej10).addComponent(PoziomWygranej9).addComponent(PoziomWygranej8).addComponent(PoziomWygranej7).addComponent(PoziomWygranej6).addComponent(PoziomWygranej5).addComponent(PoziomWygranej4)
                                 .addGroup(
                                layout.createParallelGroup().addComponent(pytanie, GroupLayout.PREFERRED_SIZE, szer/30, GroupLayout.PREFERRED_SIZE).addComponent(PoziomWygranej3)
                                         
        )
                        .addComponent(PoziomWygranej2)
                        .addComponent(PoziomWygranej1)
                        .addComponent(PoziomWygranej)
                        .addGap(wys/16)
                        .addGroup(
                                layout.createParallelGroup().addComponent(panelPrzyciskowGora, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE).addComponent(ZatrzymajGre)
                                )
                        .addGap(wys/60)        
                                .addComponent(panelPrzyciskowDol)
                        .addGap(wys/2)
                
                        
                         
                 
                
        );
      
       wygrana();
      
     
    
    
    }
   
     int los;
     JPanel panelPytania = new JPanel();
     JPanel panelPrzyciskowGora = new JPanel();
     JPanel panelPrzyciskowDol = new JPanel();
     JPanel pasekPomocy = new JPanel();
     JButton polNaPol = new JButton("Pół na Pół");
     JButton telDoPrzyjaciela = new JButton("Telefon do przyjaciela");
     JButton pomocPublicznosci = new JButton("Pomoc publiczności");
     int szer = Toolkit.getDefaultToolkit().getScreenSize().width; //pobieranie rozdzielczosci
     int wys = Toolkit.getDefaultToolkit().getScreenSize().height;
     int szerRamki = this.getSize().width; //wdrażanie rozdzielczosci
     int wysRamki = this.getSize().height;
     JFrame taRamka = this;
     int szerDziel = szer/4;
     int wysDziel = wys/4;
     boolean czyKliniete;
     int nieaktywna;
     JLabel pytanie  = new JLabel();
     JRadioButton PoziomWygranej = new JRadioButton("500");
    JRadioButton PoziomWygranej1 = new JRadioButton("1000");
    JRadioButton PoziomWygranej2 = new JRadioButton("2000");
    JRadioButton PoziomWygranej3 = new JRadioButton("5 000");
    JRadioButton PoziomWygranej4 = new JRadioButton("10 000");
    JRadioButton PoziomWygranej5 = new JRadioButton("20 000");
    JRadioButton PoziomWygranej6 = new JRadioButton("40 000");
    JRadioButton PoziomWygranej7 = new JRadioButton("75 000");
    JRadioButton PoziomWygranej8 = new JRadioButton("125 000");
    JRadioButton PoziomWygranej9 = new JRadioButton("250 000");
    JRadioButton PoziomWygranej10 = new JRadioButton("500 000");
    JRadioButton PoziomWygranej11 = new JRadioButton("1 000 000");
    JButton ZatrzymajGre = new JButton("zatrzymaj wygraną");
    
     

    @Override
    public void windowOpened(WindowEvent e) {
        if(iloscPoprawnych<1)
    JOptionPane.showMessageDialog(rootPane, "Milionerzy, jeśli jeszcze nie znasz zasad tej gry. To pozwól że Ci je przedstawię.\n Gra polega wyłącznie na odpowiadaniu na pytania. Każda odpowiedź prowadzi Cię o krok bliżej do miliona złotych. \n w trakcie rozgrywki możesz skorzystać z kół ratunkowych jednak każde z nich \n będzie do twojej dyspozycji zaledwie raz, zatem używaj ich mądrze. Powodzenia! ");
            
    }

    @Override
    public void windowClosing(WindowEvent e) {
    int opcja =  JOptionPane.showConfirmDialog(rootPane, "Czy chcesz zamknąć?");
    if(opcja == 0)
        this.dispose();       
    }

    @Override
    public void windowClosed(WindowEvent e) {
          }

    @Override
    public void windowIconified(WindowEvent e) {
          }

    @Override
    public void windowDeiconified(WindowEvent e) {
         }

    @Override
    public void windowActivated(WindowEvent e) {
    panelPrzyciskowDol.setVisible(true);
    panelPrzyciskowGora.setVisible(true);
    pytanie.setVisible(true);   
    pasekPomocy.setVisible(true);
    PoziomWygranej.setVisible(true);
     PoziomWygranej1.setVisible(true);
      PoziomWygranej2.setVisible(true);
       PoziomWygranej3.setVisible(true);
        PoziomWygranej4.setVisible(true);
         PoziomWygranej5.setVisible(true);
          PoziomWygranej6.setVisible(true);
           PoziomWygranej7.setVisible(true);
            PoziomWygranej8.setVisible(true);
             PoziomWygranej9.setVisible(true);
           PoziomWygranej10.setVisible(true);
            PoziomWygranej11.setVisible(true);
    
    if(nieaktywna > 2 && iloscPoprawnych>=1 || iloscNiePoprawnych ==1){
    panelPrzyciskowDol.setVisible(false);
    panelPrzyciskowGora.setVisible(false);
    pytanie.setVisible(false);
    pasekPomocy.setVisible(false);
    PoziomWygranej.setVisible(false);
    PoziomWygranej1.setVisible(false);
    PoziomWygranej2.setVisible(false);
    PoziomWygranej3.setVisible(false);
    PoziomWygranej4.setVisible(false);
    PoziomWygranej5.setVisible(false);
    PoziomWygranej6.setVisible(false);
    PoziomWygranej7.setVisible(false);
    PoziomWygranej8.setVisible(false);
    PoziomWygranej9.setVisible(false);
    PoziomWygranej10.setVisible(false);
    PoziomWygranej11.setVisible(false);
    }
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    panelPrzyciskowDol.setVisible(false);
    panelPrzyciskowGora.setVisible(false);
    pytanie.setVisible(false);
    pasekPomocy.setVisible(false);
       PoziomWygranej.setVisible(false);
    PoziomWygranej1.setVisible(false);
    PoziomWygranej2.setVisible(false);
    PoziomWygranej3.setVisible(false);
    PoziomWygranej4.setVisible(false);
    PoziomWygranej5.setVisible(false);
    PoziomWygranej6.setVisible(false);
    PoziomWygranej7.setVisible(false);
    PoziomWygranej8.setVisible(false);
    PoziomWygranej9.setVisible(false);
    PoziomWygranej10.setVisible(false);
    PoziomWygranej11.setVisible(false);
    nieaktywna++;
    }
    public void zaznaczonyPoziomWygranej(){
    PoziomWygranej.setEnabled(false);
    PoziomWygranej1.setEnabled(false);
    PoziomWygranej2.setEnabled(false);
    PoziomWygranej3.setEnabled(false);
    PoziomWygranej4.setEnabled(false);
    PoziomWygranej5.setEnabled(false);
    PoziomWygranej6.setEnabled(false);
    PoziomWygranej7.setEnabled(false);
    PoziomWygranej8.setEnabled(false);
    PoziomWygranej9.setEnabled(false);
    PoziomWygranej10.setEnabled(false);
    PoziomWygranej11.setEnabled(false);
        if(iloscPoprawnych <1){
            PoziomWygranej.setSelected(true);
        }
        if(iloscPoprawnych == 1){
            PoziomWygranej1.setSelected(true);
        }
         if(iloscPoprawnych == 2){
            PoziomWygranej2.setSelected(true);
        }
          if(iloscPoprawnych == 3){
            PoziomWygranej3.setSelected(true);
        }
           if(iloscPoprawnych == 4){
            PoziomWygranej4.setSelected(true);
        }
            if(iloscPoprawnych == 5){
            PoziomWygranej5.setSelected(true);
        }
             if(iloscPoprawnych == 6){
            PoziomWygranej6.setSelected(true);
        }
              if(iloscPoprawnych == 7){
            PoziomWygranej7.setSelected(true);
              }
               if(iloscPoprawnych == 8){
            PoziomWygranej8.setSelected(true);
        
        } 
               if(iloscPoprawnych == 9){
            PoziomWygranej9.setSelected(true);
        
        } 
               if(iloscPoprawnych == 10){
            PoziomWygranej10.setSelected(true);
            
        }
         if(iloscPoprawnych == 11){
            PoziomWygranej11.setSelected(true);
        }
    }
    
     public void wygrana(){
        int opcja;
        if(iloscPoprawnych > 11){
          opcja =  JOptionPane.showConfirmDialog(rootPane, "Gratulacje wygrałeś/aś milion zł! Brutto ;)");
        if(opcja <4)
             dispose();
        
                  }
    } 
    public void losujPytanie(){
       
         //DO KAZDEGO ZESTAWU NALEZY DODAC MINIMUM 4 MOZLIWE PYTANIA 
        Random rand = new Random();
        los = rand.nextInt((2-0)+1)+0;
         System.out.println(los);
         if(iloscPoprawnych == 0){
             if(los==0){
        Pytanie("<html>Ile średnio rocznie w Hurghadzie <br/> ma miejsce ataków rekinów ?<html>","Równo Dwa", "Więcej niż pięć", "Mniej niż jeden", "Zero",  'C', "Strzelam w odpowiedź C", "4% : A;  5% : B \n 80% : C; 11% D");
       }
        if(los == 1){
       Pytanie("<html>XVII-wieczna seria konfliktów między<br/> Ligą Katolicką a Unią Protestancką trwała: <html>","10 lat", "30 lat", "60 lat", "100 lat",  'B', "Chyba B", "20 : A;  65% : B \n 4% : C; 11% : D");
        }
       if(los == 2){
       Pytanie("<html>Kandydat na wysokie stanowisko często nie <br/>musi mieć odpowiednich kwalifikacji, o ile ma mocne: <html>","Plecy", "Łydki", "Dłonie", "Kolana",  'A', "no przecież że Plecy! ", "95% : A;  2% : B \n 1% : C; 2% : D");
       }
       
         }
         if(iloscPoprawnych == 1){
             if(los==0){
        Pytanie("Sygnałówka to trąbka sygnalistów. Gdzie","Na wieży mariackiej", "w myśliwstwie ", "W korporacjach", "W polityce",  'B', "Kurcze, coś pomiędzy A i B", "6% : A;  84% : B \n 12% : C; 8% : D");
       }
        if(los == 1){
       Pytanie("Imperium Inków rozciągało się: ","na północy Ameryki Północnej", "na południu Ameryki Północnej", "na wschód od Ameryki Południowej", "na zachodzie Ameryki Południowej",  'C', "nie wiem, strzelałbym w B", "5% : A;  15% : B \n 72% : C; 8% : D");
        }
       if(los == 2){
       Pytanie("Witając się a la Jurek Owsiak, powiemy: ","Hejka!", "Cze!", "Siema!", "Eluwina",  'C', "C...", "5% : A;  16% : B \n 78% : C; 1% : D");
       }
      
         }
         if(iloscPoprawnych == 2){
             if(los==0){
        Pytanie("Konduita to prowadzenie się:","Sportowych Aut", "Wszystkiego zawsze", "Prowadnic", "ludzi",  'D', "ptaszki ćwierkają że chodzi o ludzi", "1% : A;  1% : B \n 7% : C; 91% : D");
       }
        if(los == 1){
       Pytanie("<html>W filmie „Jak zabić starszą panią” z 1955 r. pieniądze z napadu<br/> kwintetu smyczkowego na furgonetkę skrywa futerał na: <html>","gęśle", "fidel płocką", "violę da gamba", "Wiolonczelę",  'D', "zgaduję że D", "1% : A;  1% : B \n 7% : C; 91% : D");
        }
       if(los == 2){
       Pytanie("Który z gruczołów wydziela sok trawienny?","Trzustka", "Szyszynka", "Nadnercze", "grasica",  'A', "zapytam szwagra... mówi że A", "81% : A;  1% : B \n 9% : C; 9% : D");
       }
       
         }
         if(iloscPoprawnych == 3){
             if(los==0){
        Pytanie("Które słowa obsługują frazeologicznie sytuację bez wyjścia?","stać i chrząkać", "kulić się w kucki", "leżeć i kwiczeć", "bekać i beczeć",  'C', "Oczywiście że C", "21% : A;  20% : B \n 58% : C; 20% : D");
       }
        if(los == 1){
       Pytanie("Irina, Masza i Olga z dramatu Antoniego Czechowa z 1900 r. to: ","babka, matka i córka", "babka i dwie wnuczki", "matka i dwie córki", "trzy siostry",  'D', "chyba matka i dwie córki, ale nie wiem. To czysty strzał", "4% : A;  6% : B \n 20% : C; 70% : D");
        }
       if(los == 2){
       Pytanie("Z tralek składa się: ","aria operowa", "balustrada", "marionetka", "centralka telefoniczna",  'B', "nie wiem, chyba Balustrada", "11% : A;  65% : B \n 4% : C; 20% : D");
       }
       
         }
         if(iloscPoprawnych == 4){
              if(los == 0){
       Pytanie("W której z wypłat ukrył się brytyjski grosz?","W honorarium", "W wynagrodzeniu", "W poborach", "W pensji",  'D', "Pensja brzmi brytyjsko", "6% : A;  14% : B \n 2% : C; 78% : D");
       }
         if(los == 1){
       Pytanie("<html>Bezpośrednio po której z wojen powstał UNICEF,<br/> żeby zapewnić żywotność i opiekę zdrowotną dla dzieci i matek?<html>","po wojnie indochińskiej", "po II wojnie światowej", "Po wojnie secesyjnej", "Po I wojnie światowej",  'B', "ojej... strzelaam... chyba C", "9% : A;  45% : B \n 37% : C; 9% : D");
       }
      if(los == 2){
       Pytanie("O czym jest piosenka „Prząśniczka” Czeczota i Moniuszki?","o przędzeniu wełny", "o tkaniu tkaniny", "o dzianiu dzianiny", "o miłości i zdradzie",  'D', "90% piosenek jest o miłośći", "21% : A;  20% : B \n 20% : C; 58% : D");
       }
         }
         if(iloscPoprawnych == 5){
             if(los == 0){
       Pytanie("Który z nich główną rolę zagrał tylko w jednym filmie z serii o Jamesie Bondzie?","Sean Connery", "Roger Moore", "George Lazenby", "Pierce Brosnan",  'C', "George Lazenby", "11% : A;  65% : B \n 4% : C; 20% : D");
       }
        if(los == 1){
       Pytanie("Zwyczajowo nazywany jest agrestem.","porzeczka agrest", "malina agrest", "agrest jeżyna", "agrest borówka",  'A', "Od babci wiem że A", "91% : A;  3% : B \n 2% : C; 4% : D");
        }
       if(los == 2){
       Pytanie("Które to slangowe no pewnie?","no rejczel", "yes ros", "no fibi", "yes czendler",  'A', "No Reeejczeel", "91% : A;  3% : B \n 2% : C; 4% : D");
       }
       
             
         }
         if(iloscPoprawnych == 6){
             if(los==0){
        Pytanie("Który ptak dzieli nazwę z australijskimi butami z owczej skóry?","ibis", "kakadu", "lora", "emu",  'D', "Zgaduję że A", "30% : A;  4% : B \n 8% : C; 58% : D");
       }
        if(los == 1){
       Pytanie("Krzywy Róg to miasto w obwodzie dniepropertowskim, czyli: ", "W Ukrainie", "W Białorusi", "W Łotwie","W Estonii" ,  'A', "Ukraina", "70% : A;  4% : B \n 8% : C; 22% : D");
        }
       if(los == 2){
       Pytanie("Inna nazwa tej gry to inteligencja. ","kółko i krzyżyk", "wisielec", "państwa-miasta", "okręty",  'C', "Albo A, albo C", "40% : A;  9% : B \n 40% : C; 11% : D");
       }
             
         }
         if(iloscPoprawnych == 7){if(los==0){
        Pytanie("Jeśli pokonujemy rzekę w bród, to na pewno:","nie pieszo", "wpław", "nie łodzią", "z dużym bagażem",  'C', "na 100% C", "20% : A;  15% : B \n 65% : C; 5% : D");
       }
        if(los == 1){
       Pytanie("Perykles, który żył w V w. p.n.e. w Atenach, uważany jest za ojca:","demokracji", "oligarchii", "monarchii", "tyranii",  'A', "tam chyba powstała demokracja", "85% : A;  5% : B \n 2% : C; 8% : D");
        }
       if(los == 2){
       Pytanie("<html>W jakim utworze Poeta mówi do Gospodarza”(…)<br/> a tu pospolitość skrzeczy, a tu pospolitość tłoczy”?<html>","w „Weselu” Wyspiańskiego", "w „Ślubie” Gombrowicza", "W „Dziadach” Mickiewicza", "w „Żonie modnej” Krasickiego",  'A', "Oczywiście że w A!", "85% : A;  5% : B \n 2% : C; 8% : D");
       }
       
             
         }
         if(iloscPoprawnych == 8){
             if(los==0){
        Pytanie(" Koniczynka to klasyczny węzeł typu WA, czyli węzeł:","żeglarski", "Komunikacyjny", "radiowy", "chłonny",  'B', "Ja bym dał B", "5% : A;  75% : B \n 2% : C; 23% : D");
       }
        if(los == 1){
       Pytanie("Jakiej duszy nie ma, kiedy nikogo nie ma?","żywej", "martwej", "dusznej", "uduchowionej",  'A', "no żywej", "45% : A;  50% : B \n 2% : C; 3% : D");
        }
       if(los == 2){
       Pytanie("Geolodzy dzielą skały na trzy podstawowe grupy. W tym podziale nie ma skał: ","osadowych", "magmowych", "metamorficznych", "oceanicznych",  'D', "No oceanicznych", "3% : A;  2% : B \n 12% : C; 83% : D");
       }
       
             
         }
         if(iloscPoprawnych == 9){
             if(los==0){
        Pytanie("Kapnąć to uronić kroplę, a kapnąć się: ","wziąć prysznic", "domyślić się", "napić się kapkę", "obudzić się",  'B', "nie wiem, chyba B", "3% : A;  62% : B \n 12% : C; 33% : D");
       }
        if(los == 1){
       Pytanie("Co nie jest prawdą o kluskach śląskich?","są gotowanych ziemniaków", "mają dziurkę na wylot", "są okrągłe", "mają wgłębienie w centrum",  'B', "B na 100%", "3% : A;  62% : B \n 12% : C; 33% : D");
        }
       if(los == 2){
       Pytanie(" U Anglików out of the blue, a u nas:","mieć czegoś wyżej uszu", "jak grom z jasnego nieba", "mieć rękę do kwiatów", "między młotem a kowadłem",  'B', "jak grom z jasnego nieba", "3% : A;  62% : B \n 12% : C; 33% : D");
       }
      
             
         }
         if(iloscPoprawnych == 10){
             if(los==0){
        Pytanie("Co ma odziomek?","piorunochron", "żaglówka", "dom z werandą", "drzewo",  'D', "strzelam że C", "3% : A;  2% : B \n 22% : C; 73% : D");
       }
        if(los == 1){
       Pytanie("<html>Kto jest drugoplanowym bohaterem filmu <br/> Paolo Sorrentino „To była ręka Boga” z 2021 roku?<html>","Pele", "Lionel Messi", "Robert Lewandowski", "Diego Maradona",  'D', "to był chyba Maradona", "3% : A;  2% : B \n 12% : C; 83% : D");
        }
       if(los == 2){
       Pytanie("Które to sikory?","zegary wiszące", "zegarki naręczne", "zegary z kukułką", "zegary astronomiczne",  'B', "nie wiem", "5% : A;  74% : B \n 1% : C; 20% : D");
       }
       
       
             
         }
         if(iloscPoprawnych == 11){
             if(los==0){
        Pytanie("Laurazja to:","miasto w Azji", "metropolia nad Laurą", "dawny kontynent", "boska żona Gondwany",  'C', "nie wiem, chyba C", "5% : A;  74% : B \n 1% : C; 20% : D");
       }
        if(los == 1){
       Pytanie("Który turmalin zazwyczaj jest bezbarwny?","achroit", "rubelit", "verdelit", "indigolit",  'A', "Może C?", "55% : A;  13% : B \n 12% : C; 20% : D");
        }
       if(los == 2){
          Pytanie("<html>Kto w „Trzy po trzy” wspominał taki oto napis na <br/>transparencie: „O Sasie, w dobrym czasie, drugi raz walisz, przez Kalisz”?<html>","Aleksander Fredro", "Mikołaj Rej", "Adam Mickiewicz", "Juliusz Słowacki",  'A', "nie wiem, może Fredro", "75% : A;  10% : B \n 4% : C; 11% : D");
       }
       
       
             
         }
         
        
    }
    
    
     public void Pytanie(String trescPytania,String trescOdpowiedziA, String trescOdpowiedziB, String trescOdpowiedziC, String trescOdpowiedziD, char poprawnaOdpowiedz, String telefonDoPrzyjaciela, String publicznosc){
     
         
     
     pytanie.setText(trescPytania);
     int dlugoscPytania = trescPytania.length();
     
     if(dlugoscPytania < 20)
     pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 30));
     if(dlugoscPytania >= 20 && dlugoscPytania <40)
      pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 25));
     if(dlugoscPytania >= 40 && dlugoscPytania <60)
          pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 20));
     if(dlugoscPytania >= 60 && dlugoscPytania <80)
          pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 15));
     if(dlugoscPytania >= 80 && dlugoscPytania <100)
          pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 10));
     if(dlugoscPytania >= 100 && dlugoscPytania <150)
          pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 8));
     if(dlugoscPytania >= 150)
          pytanie.setFont(new Font(Font.MONOSPACED, Font.PLAIN , 7));
     panelPytania.add(pytanie);
        
     JButton odpA = new JButton("A: " + trescOdpowiedziA);
     JButton odpB = new JButton("B: " + trescOdpowiedziB);
     JButton odpC = new JButton("C: " + trescOdpowiedziC);
     JButton odpD = new JButton("D: " + trescOdpowiedziD);
     panelPrzyciskowGora.add(odpA);
     panelPrzyciskowDol.add(odpB);
     panelPrzyciskowGora.add(odpC);
     panelPrzyciskowDol.add(odpD);
     
     
     telDoPrzyjaciela.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             czyKliniete = true;
             iloscWykorzystanychTelefonow++;
             System.out.println("ilosc wyk: " + iloscWykorzystanychPolnaPol);
             if(iloscWykorzystanychTelefonow == 1){
                 telDoPrzyjaciela.setBackground(Color.red);
                 telDoPrzyjaciela.setEnabled(false);
             }
             int pomoc;
         pomoc = JOptionPane.showConfirmDialog(pasekPomocy, telefonDoPrzyjaciela);
         }
         
     });
     
     pomocPublicznosci.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
          iloscWykorzystanychPublicznosci++;
          if(iloscWykorzystanychPublicznosci == 1){
              pomocPublicznosci.setBackground(Color.red);
              pomocPublicznosci.setEnabled(false);
          }
          int pomoc;
         pomoc = JOptionPane.showConfirmDialog(pasekPomocy, publicznosc);
         
         }
         
     });
     
    polNaPol.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             iloscWykorzystanychPolnaPol++;
             System.out.println("ilosc wyk: " + iloscWykorzystanychPolnaPol);
             if(iloscWykorzystanychPolnaPol >= 1){
                 polNaPol.setBackground(Color.red);
                 polNaPol.setEnabled(false);
             }
         if(poprawnaOdpowiedz == 'A'){
             odpB.setVisible(false);
             odpD.setVisible(false);}
         
         if(poprawnaOdpowiedz == 'B'){
             odpD.setVisible(false);
             odpC.setVisible(false);}
        
         if(poprawnaOdpowiedz == 'C'){
             odpA.setVisible(false);
             odpD.setVisible(false);}
         if(poprawnaOdpowiedz == 'D'){
             odpA.setVisible(false);
             odpB.setVisible(false);}
         
         }
         
     });
     
     odpA.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               int opcja; 
               int opcja2;
                if(poprawnaOdpowiedz == 'A'){
                opcja =  JOptionPane.showConfirmDialog(rootPane, "Brawo, A to poprawna odpowiedź. Gramy dalej?");
                if(opcja == 0){
                    iloscPoprawnych++;
                    System.out.println("dalej"); 
                    losujPytanie();
                    new KolejnePytanie(taRamka).setVisible(true);
                System.out.println("ilosc A" + iloscPoprawnych);}
                else if(opcja == 1)
                    dispose();
                }
                else{
                    iloscNiePoprawnych = 1;
                   String odmiana = "pytań";
                    if(iloscPoprawnych == 1)
                    odmiana = "pytanie";
                    else if(iloscPoprawnych>1 && iloscPoprawnych <5)
                      odmiana = "pytania";
                opcja2 = JOptionPane.showConfirmDialog(rootPane, "Niestety, odpowiedź A nie była poprawna. To odpowiedź " + poprawnaOdpowiedz + " była poprawna. Odpowiedziano poprawnie na: " + iloscPoprawnych + " " + odmiana);
                if(opcja2<4)
                    dispose();
                }
            }
     });
       odpB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int opcja; 
                int opcja2;
                if(poprawnaOdpowiedz == 'B'){
                opcja =  JOptionPane.showConfirmDialog(rootPane, "Brawo, B to poprawna odpowiedź. Gramy dalej?");
               if(opcja == 0){
                     iloscPoprawnych++;
                    System.out.println("dalej"); 
                    losujPytanie();
               new KolejnePytanie(taRamka).setVisible(true);}
                 else if(opcja == 1)
                    dispose();}
                else{
                    iloscNiePoprawnych = 1;
                   String odmiana = "pytań";
                    if(iloscPoprawnych == 1)
                    odmiana = "pytanie";
                    else if(iloscPoprawnych>1 && iloscPoprawnych <5)
                      odmiana = "pytania";
                opcja2 = JOptionPane.showConfirmDialog(rootPane, "Niestety, odpowiedź B nie była poprawna. To odpowiedź " + poprawnaOdpowiedz + " była poprawna. Odpowiedziano poprawnie na: " + iloscPoprawnych + " " + odmiana);
                if(opcja2<4)
                    this.dispose();
                }}

         private void dispose() {
             throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
         }
     });
         odpC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            int opcja; 
            int opcja2;
                if(poprawnaOdpowiedz == 'C'){
                opcja =  JOptionPane.showConfirmDialog(rootPane, "Brawo, C to poprawna odpowiedź. Gramy dalej?");
                if(opcja == 0){
                     iloscPoprawnych++;
                    System.out.println("dalej"); 
                    losujPytanie();
                new KolejnePytanie(taRamka).setVisible(true);}
                else if(opcja == 1)
                    dispose();}
                else{
                    iloscNiePoprawnych = 1;
                String odmiana = "pytań";
                    if(iloscPoprawnych == 1)
                    odmiana = "pytanie";
                    else if(iloscPoprawnych>1 && iloscPoprawnych <5)
                      odmiana = "pytania";
                opcja2 = JOptionPane.showConfirmDialog(rootPane, "Niestety, odpowiedź C nie była poprawna. To odpowiedź " + poprawnaOdpowiedz + " była poprawna. Odpowiedziano poprawnie na: " + iloscPoprawnych + " " + odmiana);
               if(opcja2<4)
                    dispose();
                }   
            }
     });
           odpD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            int opcja; 
            int opcja2;
                if(poprawnaOdpowiedz == 'D'){
                opcja =  JOptionPane.showConfirmDialog(rootPane, "Brawo, D to poprawna odpowiedź. Gramy dalej?");
                if(opcja == 0){
                    iloscPoprawnych++;
                    System.out.println("dalej"); 
                    losujPytanie();
                new KolejnePytanie(taRamka).setVisible(true);}
                 else if(opcja == 1)
                    dispose();}
                else{
                    iloscNiePoprawnych = 1;
                String odmiana = "pytań";
                    if(iloscPoprawnych == 1)
                    odmiana = "pytanie";
                    else if(iloscPoprawnych>1 && iloscPoprawnych <5)
                      odmiana = "pytania";
                opcja2 = JOptionPane.showConfirmDialog(rootPane, "Niestety, odpowiedź D nie była poprawna. To odpowiedź " + poprawnaOdpowiedz + " była poprawna. Odpowiedziano poprawnie na: " + iloscPoprawnych + " " + odmiana);
               if(opcja2<4)
                    dispose();
                }
                
            }
     });
         
      
     
     }
     
     
    public static void main(String[] args) {
        new Milionerzy().setVisible(true);
    }
    static int iloscPoprawnych = 0;
    static int iloscWykorzystanychTelefonow = 0;
    public static int iloscWykorzystanychPolnaPol = 0;
    static int iloscWykorzystanychPublicznosci = 0;
    static int iloscNiePoprawnych = 0;
    
}


